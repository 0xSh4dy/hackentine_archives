import MainComponent from "./MainComponent"
import Navbar from "./Navbar"

export default function Home(){
    return <div>
        <Navbar/>
        <MainComponent/>
    </div>
}