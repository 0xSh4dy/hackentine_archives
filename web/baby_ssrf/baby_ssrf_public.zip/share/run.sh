#!/bin/bash
exec python3 app1/app.py &
exec python3 app2/app.py